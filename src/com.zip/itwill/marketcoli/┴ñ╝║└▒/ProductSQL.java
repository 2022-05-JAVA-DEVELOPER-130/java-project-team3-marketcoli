package com.itwill.marketcoli.정성윤;

public class ProductSQL {
	
	//SQL 문장을 채워서 사용하세요
	
	public static final String PRODUCT_INSERT
								= " ";
	
	public static final String PRODUCT_UPDATE 
								= " ";
	
	public static final String PRODUCT_DELETE 
								= " ";
	
	public static final String PRODUCT_SELECT_BY_NO 
								= " ";
	
	public static final String PRODUCT_SELECT_ALL 
								= " ";

}
