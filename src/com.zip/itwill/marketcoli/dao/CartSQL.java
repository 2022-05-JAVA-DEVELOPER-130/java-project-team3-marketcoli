package com.itwill.marketcoli.dao;

public class CartSQL {

	//SQL 문장을 채워서 사용하세요
	
	public static final String CART_INSERT
								= " ";
	
	public static final String CART_UPDATE 
								= " ";
	
	public static final String CART_DELETE 
								= " ";
	
	public static final String CART_SELECT_BY_NO 
								= " ";
	
	public static final String CART_SELECT_ALL 
								= " ";
}
