package com.itwill.marketcoli.dao;

public class OrdersSQL {

	//SQL 문장을 채워서 사용하세요
	
	public static final String ORDERS_INSERT
								= " ";
	
	public static final String ORDERS_UPDATE 
								= " ";
	
	public static final String ORDERS_DELETE 
								= " ";
	
	public static final String ORDERS_SELECT_BY_NO 
								= " ";
	
	public static final String ORDERS_SELECT_ALL 
								= " ";
}
