package com.itwill.marketcoli.dao;

public class UserInfoSQL {
	
	//SQL 문장을 채워서 사용하세요
	
	public static final String USERINFO_INSERT
								= " ";
	
	public static final String USERINFO_UPDATE 
								= " ";
	
	public static final String USERINFO_DELETE 
								= " ";
	
	public static final String USERINFO_SELECT_BY_NO 
								= " ";
	
	public static final String USERINFO_SELECT_ALL 
								= " ";

}
