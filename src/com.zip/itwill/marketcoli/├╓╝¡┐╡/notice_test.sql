--Notice - Test

select * from notice;

desc notice;

desc review;

